version: '3.9'

services:
  frontend:
    image: gowdaman/mailai-frontend:latest
    ports:
      - "8000:8000"
    restart: always

  backend:
    image: gowdaman/mailai-backend:latest
    ports:
      - "7000:7000"
    environment:
      - OLLAMA_HOST=http://ollama:11434
    restart: always

  ollama:
    image: ollama/ollama
    ports:
      - "11435:11434"
    volumes:
      - ollama_data:/root/.ollama
    entrypoint: >
      sh -c "ollama pull mistral:7b-instruct-q4_K_M && ollama serve"
    restart: always

volumes:
  ollama_data:
wwoh jbxy nqpg amkf